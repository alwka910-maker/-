مشروع Flutter جاهز لتطبيق 'قصص محمد ونجمة'.
لفتح المشروع:
1) انسخ المجلد إلى جهازك مع تثبيت Flutter SDK.
2) شغّل: flutter pub get
3) بِنِ التطبيق: flutter run

يحتوي على:
- lib/main.dart (الكود الرئيسي)
- pubspec.yaml
- assets/ (مجلد فارغ لإضافة صور أو ملفات لاحقًا)
