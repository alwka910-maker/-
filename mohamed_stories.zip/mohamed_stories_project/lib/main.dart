import 'package:flutter/material.dart';

void main() {
  runApp(const MohamedStoriesApp());
}

class MohamedStoriesApp extends StatelessWidget {
  const MohamedStoriesApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'قصص محمد ونجمة',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        fontFamily: 'Arial',
      ),
      home: const SplashScreen(),
      // Force RTL for Arabic
      localizationsDelegates: [],
      supportedLocales: const [Locale('ar')],
    );
  }
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Navigate after short delay
    Future.delayed(const Duration(seconds: 2), () {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    });
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.deepPurple, Colors.purpleAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Icon(Icons.star, size: 100, color: Colors.yellow),
              SizedBox(height: 20),
              Text(
                'قصص محمد ونجمة',
                style: TextStyle(
                  fontSize: 30,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  static final List<String> stories = List.generate(
      20, (index) => "مغامرة ${index + 1} لمحمد ونجمة");

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('فهرس القصص'),
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: stories.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: const Icon(Icons.star, color: Colors.yellow),
            title: Text(stories[index]),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) =>
                          StoryScreen(title: stories[index])));
            },
          );
        },
      ),
    );
  }
}

class StoryScreen extends StatelessWidget {
  final String title;

  const StoryScreen({Key? key, required this.title}) : super(key: key);

  static const String storyText =
      "هنا نص القصة، يمكنك تغييره لاحقًا لكل مغامرة لتكون القصة الفعلية.";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: const Padding(
        padding: EdgeInsets.all(16.0),
        child: Text(
          storyText,
          style: TextStyle(fontSize: 18, height: 1.5),
          textDirection: TextDirection.rtl,
        ),
      ),
    );
  }
}
